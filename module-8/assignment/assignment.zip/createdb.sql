CREATE TABLE html_assignment (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `fn` varchar(50) NOT NULL,
    `ln` varchar(50) NOT NULL,
    `email` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL
);